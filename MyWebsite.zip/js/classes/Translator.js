"use strict";
class Translator {
    constructor(textNodes) {
        this.textNodes = textNodes;
    }
    translate(countryId) {
        throw new Error("Method not implemented.");
    }
}
