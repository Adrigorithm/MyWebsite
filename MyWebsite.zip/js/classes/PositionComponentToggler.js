class PositionComponentToggler {
    constructor() {
        this.activateOnYOffsetElements = new Map();
    }
    addComponents(activateOnYOffsetElements) {
        this.activateOnYOffsetElements = activateOnYOffsetElements;
        this.initialise();
    }
    initialise() {
        this.work();
        document.addEventListener("scroll", () => {
            this.work();
        });
        window.addEventListener("resize", () => {
            this.work();
        });
    }
    work() {
        for (let [key, value] of this.activateOnYOffsetElements) {
            if (typeof value === "string") {
                switch (value) {
                    case "h-screen":
                        value = window.visualViewport.height;
                        break;
                    default:
                        value = 100;
                }
            }
            if (window.scrollY >= value)
                key.classList.remove("hidden");
            else
                key.classList.add("hidden");
        }
    }
}
export { PositionComponentToggler };
