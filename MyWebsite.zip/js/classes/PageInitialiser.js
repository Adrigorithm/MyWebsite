import { Locales } from "../enums/Locales.js";
import { Themes } from "../enums/Themes.js";
class PageInitialiser {
    constructor() {
        this.settings = {
            locale: localStorage.getItem("locale") ?? Locales.English,
            theme: localStorage.getItem("theme") ?? Themes.Light
        };
    }
    applyLocale(destination, urlLocale, locale) {
        if (locale == urlLocale)
            return;
        location.assign(`/${locale}/${destination}`);
    }
    processUrl() {
        let path = location.pathname.substring(1);
        let localeSepIndex = path.indexOf('/');
        this.applyLocale(path.substring(localeSepIndex + 1), path.substring(0, localeSepIndex), this.settings.locale);
    }
}
export { PageInitialiser };
