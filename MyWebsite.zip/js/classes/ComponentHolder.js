import { PositionComponentToggler } from "./PositionComponentToggler.js";
import { SectionIndicator } from "./SectionIndicator.js";
import { SettingContainer } from "./SettingContainer.js";
import { SimpleSlider } from "./SimpleSlider.js";
import { SlideShow } from "./SlideShow.js";
import { Squarifier } from "./Squarifier.js";
class ComponentHolder {
    constructor() {
        this.settingContainer = new SettingContainer();
        this.settingContainer.processUrl();
        this.sectionIndicators = [];
        this.simpleSliders = [];
        this.slideShows = [];
        this.squarifier = new Squarifier();
        this.positionComponentToggler = new PositionComponentToggler();
    }
    addPositionComponentToggler(activateOnYOffsetElements) {
        this.positionComponentToggler.addComponents(activateOnYOffsetElements);
    }
    addSettings(localeElements, themeElements) {
        this.settingContainer.initSettingsMenu(localeElements, themeElements);
    }
    addSquares(missingHeightSquares, missingWidthSquares) {
        this.squarifier.initialise(missingWidthSquares, missingHeightSquares);
    }
    addSectionIndicator(siSections, siContents) {
        this.sectionIndicators.push(new SectionIndicator(siSections, siContents));
    }
    addSimpleSlider(rangeInputElement, elements) {
        this.simpleSliders.push(new SimpleSlider(rangeInputElement, elements));
    }
    addSlideShow(previousButton, nextButton, backgroundContents, background, imgPaths) {
        this.slideShows.push(new SlideShow(previousButton, nextButton, backgroundContents, background, imgPaths));
    }
}
export { ComponentHolder };
