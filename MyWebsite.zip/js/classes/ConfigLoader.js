"use strict";
class ConfigLoader {
    init() {
        this.loadSettings();
        this.localeRedirect();
    }
    localeRedirect() {
        let path = location.pathname.split('/');
        let pathLocale = path[1];
        if (pathLocale == '') {
            location.assign(`/${this.settings.get("locale")}`);
            return;
        }
    }
    loadSettings() {
        this.settings.set("locale", localStorage.getItem("locale") ?? Locales.English);
    }
}
