import { ComponentHolder } from "./classes/ComponentHolder.js";
let componentHolder = undefined;
initialise();
document.addEventListener("DOMContentLoaded", loaded);
function initialise() {
    initComponentHolder();
}
function loaded() {
    initSectionIndicators();
    initSimpleSliders();
    initSlideShows();
    initSquarifier();
    initSettings();
    initPositionComponentToggler();
}
function initComponentHolder() {
    componentHolder = new ComponentHolder();
}
function initSettings() {
    let localeElements = document.getElementById("localeSettings")?.children;
    let themeElements = document.getElementById("themeSettings")?.children;
    componentHolder?.addSettings(Array.from(localeElements ?? []), Array.from(themeElements ?? []));
}
function initSectionIndicators() {
    let siSections = document.getElementsByClassName("si-section");
    let siContents = document.getElementsByClassName("si-content");
    for (let index = 0; index < siSections.length; index++) {
        componentHolder.addSectionIndicator(Array.from(siSections[index].children), Array.from(siContents[index].children));
    }
}
function initSimpleSliders() {
    let sliders = document.getElementsByClassName("simpleSlider");
    let sliderContents = document.getElementsByClassName("simpleSliderContent");
    for (let index = 0; index < sliders.length; index++) {
        let inputElement = sliders[index];
        componentHolder.addSimpleSlider(inputElement, Array.from(sliderContents).slice(0, Number.parseInt(inputElement.max) + 1));
    }
}
function initSlideShows() {
    let slideShows = document.getElementsByClassName("slideShow");
    for (let index = 0; index < slideShows.length; index++) {
        let slideShow = slideShows[index];
        let previousButton = slideShow.firstElementChild;
        let nextButton = slideShow.lastElementChild;
        let contents = Array.from(slideShow.children).slice(1, -1);
        let imgPaths = getData(slideShow.id);
        componentHolder.addSlideShow(previousButton, nextButton, contents, slideShow, imgPaths);
    }
}
function initSquarifier() {
    let missingHeightSquares = document.getElementsByClassName("noYElement");
    let missingWidthSquares = document.getElementsByClassName("noXElement");
    componentHolder.addSquares(Array.from(missingHeightSquares), Array.from(missingWidthSquares));
}
function initPositionComponentToggler() {
    let map = new Map();
    let elements = document.getElementsByClassName("yOffsetToggle");
    for (let index = 0; index < elements.length; index++) {
        const element = elements[index];
        map.set(element, element.dataset.value);
    }
    componentHolder.addPositionComponentToggler(map);
}
function getData(id) {
    switch (id) {
        case "slideShowProjects":
            return [
                "bg-[url(/assets/img/projects/Adribot.git.avif)]",
                "bg-[url(/assets/img/projects/AdriTemplater.git.avif)]",
                "bg-[url(/assets/img/projects/MyWebsite.git.avif)]"
            ];
        default:
            return [];
    }
}
